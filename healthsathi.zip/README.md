# Sehat Saathi

Describe how you feel, in your own language. Get quick relief ideas, common over-the-counter options to ask a pharmacist about, and a clear signal on whether to see a doctor.

**General information only. Not medical advice.**

## Run it

```
pip install -r requirements.txt
cp .env.example .env        # then paste your key after SARVAM_API_KEY=
python app.py
```

Open http://localhost:5000. The API key is read on the server and never sent to the browser.
Optional: set `SARVAM_MODEL` in `.env` to change the model (default `sarvam-105b-conversations`).

## How it works

1. **Fixed safety rules run first.** Emergency warning signs (chest pain, trouble breathing, fainting, and similar) return "get help now" and 112 without calling the AI, so this works even if the API is down.
2. Age, pregnancy and how long symptoms have lasted can raise the level to "see a doctor soon".
3. The Sarvam chat model writes the answer in the chosen language as JSON.
4. The final level is the higher of the rules and the AI. The AI can never lower it.
5. No medicine list is shown for children under 12 or during pregnancy. Any dose-like text (for example "500 mg") is removed from the answer.

## Limits

- Emergency keyword matching covers English, Hindi, Marathi and Hinglish only, and keywords can miss things. Treat it as a safety net, not a guarantee.
- The page labels are English. Only the advice itself is in the chosen language.
- Not reviewed by a doctor. Have a medical professional review the rules and prompt before real-world use.
- No accounts, no history. Symptoms are not stored or logged.

## Files

- `app.py`: Flask server and `/api/advice` endpoint
- `static/index.html`: the web page
- `main.py`: the original one-call Sarvam test (optional)
